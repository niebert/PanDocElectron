Read Me: Folder bib
-------------------
This folder contains available bibtex databases for PanDoc 
document conversion. It contains CSL-styles e.g. IEEE or APA citation 
style. Dependent on the requirements papers and presentations the styles
define how citations are placed in the converted document
E.g. [2] as IEEE citation or (Miller 2001) as APA style.

More styles are available are available at GitHub:

  https://github.com/citation-style-language/styles
  
Niehaus, Engelbert