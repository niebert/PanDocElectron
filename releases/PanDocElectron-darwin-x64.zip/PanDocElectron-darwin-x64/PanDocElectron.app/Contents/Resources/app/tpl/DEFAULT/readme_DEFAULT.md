Folder DEFAULT
--------------
This folder contains all default input files, that are
used when you create a new project with PANDOCmenu.sh

Subdirectories
--------------
The subdirectories define the input formats.

E.g. if users choose "myinput.wiki" as new input file 
in PANDOCmenu.sh then the menu copies /tpl/DEFAULT/wiki/default.wiki
into the folder /projects/myinput/ as input file myinput.wiki.

* wiki WikiMedia Input Files
* md   MarkDown Input Files